import 'dart:async';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/models/liveresponse.dart';
import 'package:zeenews/models/photoresponse.dart';

abstract class ZeeNewsAPIInterface {
  Future<List<HomeResponseData>> getHomeScreen();
  Future<List<LiveResponseData>> getLiveScreen();
  Future<List<PhotoResponseData>> getPhotoScreen();
  Future<List<PhotoResponseData>>  getVideoScreen();
}