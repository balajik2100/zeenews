import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tags/tag.dart';
import 'package:zeenews/services/zee_api_service.dart';
import 'package:zeenews/view_models/main_page_view_model.dart';
import 'package:zeenews/views/pages/main_page.dart';

final MainPageViewModel mainPageVM =
    MainPageViewModel(apiZeeNews: ZeeAPIService());

class AddTabItem extends StatefulWidget {
  final MainPageViewModel mainPageVM;

  // AddTabItem({@required this.mainPageVM});

  AddTabItem({Key key, this.title, this.mainPageVM})
      : super(key: key);

  final String title;

  @override
  _AddTabItem createState() => _AddTabItem();
}

class _AddTabItem extends State<AddTabItem>
    with SingleTickerProviderStateMixin {
  final List<String> _list = [
    // 'LIVE TV',
    //  'VIDEOS',
    //  'PHOTOS',
    'WORLD',
    'INDIA',
    'ENTERTAINMENT',
    'LIFE STYLE',
    'TECHNOLOGY',
    'STATES',
    'BUSINESS',
    'BHOJPURI',
  ];

  bool _symmetry = false;
  bool _singleItem = false;
  bool _horizontalScroll = false;
  int _column = 3;
  double _fontSize = 16;

  @override
  void initState() {
    super.initState();

    _items = _list.toList();
  }

  List _items;
  List<String> tempList = [];

  final GlobalKey<TagsState> _tagStateKey = GlobalKey<TagsState>();

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Column(
        //adjust the screen to fit widgets
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Expanded(
            flex: 1,
            child: headerSection(),
          ),
          Expanded(
            flex: 8,
            child: _tags1,
          ),
          Expanded(
            flex: 1,
            child: clearSection(),
          ),
          Expanded(
            flex: 1,
            child: saveSection(),
          ),
        ],
      ),
    );
  }

  //showing tags view
  Widget get _tags1 {
    return Tags(
      alignment: WrapAlignment.center,
      key: _tagStateKey,
      symmetry: _symmetry,
      columns: _column,
      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items.length,
      itemBuilder: (index) {
        final item = _items[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          active: false,
          pressEnabled: true,
          activeColor: Colors.red,
          highlightColor: Colors.green,
          singleItem: _singleItem,
          customData: item,
          // splashColor: Colors.green,
          combine: ItemTagsCombine.withTextBefore,
          //removeButton: ItemTagsRemoveButton(),
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(
            fontSize: _fontSize,
          ),
          onPressed: (item) => {},
        );
      },
    );
  }




// Allows you to get a list of all the ItemTags

  //header section with close icon
  headerSection() {
    return ListTile(
        contentPadding: EdgeInsets.all(18.0),
        title: Text(
          "Topics",
          style: TextStyle(
              color: Colors.black, fontSize: 22.0, fontWeight: FontWeight.bold),
        ),
        trailing: GestureDetector(
            onTap: () {
              //close the page with out updating menu changes
              //Navigator.pop(context);
              Navigator.of(context).pop();
            },
            child: Container(
              child: Icon(
                Icons.close,
                color: Colors.black,
              ),
            )
        )
    );
  }

  //clear the selected tabs menu
  clearSection() {
    return GestureDetector(
        onTap: () {
          tempList = [];
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => AddTabItem()))
              .then((_) => AddTabItem());



//          prefix0.Navigator.pop(context);
//          Navigator.push(
//            context,
//            PageRouteBuilder(
//              pageBuilder: (context, anim1, anim2) => AddTabItem(),
//              transitionsBuilder: (context, anim1, anim2, child) => FadeTransition(opacity: anim1, child: child),
//              transitionDuration: Duration(seconds: 1),
//            ),
//          );


        },
        child: Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
          child: Text(
            "Clear All",
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.black,
                fontSize: 16.0,
                fontWeight: FontWeight.normal,
                decoration: TextDecoration.underline),
          ),
        ));
  }

  //update selected tabs menu
  saveSection() {
    return GestureDetector(
        onTap: () {
          _getActiveTags();
          //navigation and update the screen
          Navigator.of(context).pop();
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => MainPage(
            viewModel: mainPageVM,
            list: tempList,
          )));
        },
        child: Container(
          alignment: Alignment.center,
          color: Colors.black,
          padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
          child: Text(
            "Save",
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.bold),
          ),
        ));
  }

  void _getActiveTags() {
    List<Item> lst = _tagStateKey.currentState?.getAllItem;
    lst.where((tag) => tag.active).forEach((tag) => tempList.add(tag.title));
  }



}
