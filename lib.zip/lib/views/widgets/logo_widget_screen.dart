

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zeenews/models/homeresponse.dart';

import 'common_screen_item.dart';

class LogoWidgetScreen extends StatelessWidget{

  final HomeResponseData film;

  LogoWidgetScreen({@required this.film});


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    var bannerWidget = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
            padding: EdgeInsets.all(5.0),
            decoration: BoxDecoration(
              border: Border.all(
                  width: 0.2,
                  color: Colors
                      .grey //                   <--- border width here
              ),
            ),
            child: Stack(
              children: <Widget>[
                               Container(
                                 padding: EdgeInsets.all(5.0),
                  width: 140.0,
                  height: 100.0,
                  decoration: BoxDecoration(
                    borderRadius:
                    BorderRadius.vertical(top: Radius.circular(20.0),bottom: Radius.circular(20.0)),
                    image: DecorationImage(
                      image: NetworkImage(
                          'https://devpwa.zeenews.com/static/assets/photo_thumb3.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

              ],
            )),
      ],
    );


    // TODO: implement build
    return bannerWidget;
  }

}