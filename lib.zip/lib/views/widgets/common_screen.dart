import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/view_models/main_page_view_model.dart';
import 'package:zeenews/views/widgets/banner_widget_screen.dart';
import 'package:zeenews/views/widgets/blog_widget_screen.dart';
import 'package:zeenews/views/widgets/chip_widget_screen.dart';
import 'package:zeenews/views/widgets/gallery_widget_screen.dart';
import 'common_screen_item.dart';
import 'logo_widget_screen.dart';
import 'no_internet_connection.dart';

class CommonScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //Size size = MediaQuery.of(context).size;

    return ScopedModelDescendant<MainPageViewModel>(
      builder: (context, child, model) {
        return FutureBuilder<List<HomeResponseData>>(
          future: model.home,
          // ignore: missing_return
          builder: (_, AsyncSnapshot<List<HomeResponseData>> snapshot) {
            switch (snapshot.connectionState) {
              case ConnectionState.none:
              case ConnectionState.active:
              case ConnectionState.waiting:
                return Center(child: const CircularProgressIndicator());
              case ConnectionState.done:
                if (snapshot.hasData) {
                  var films = snapshot.data;
                  return ListView.builder(
                    itemCount: films == null ? 0 : films.length,
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      var film = films[index];
                      if (index == 0) {
                        return BannerScreenWidget(film: film);
                      } else if (index == 1) {
                        return AlbumWidgetScreen(film: film);
                      } else if (index == 2) {
                        //logo widget
                        return LogoWidgetScreen(film: film);
                      } else if (index == 3) {
                        //blog widget
                        return BlogWidgetScreen(film: film);
                      } else if (index == 4) {
                        return CustomChipWidget(film: film);
                      } else {
                        return CommonScreenItem(film: film);
                      }
                    },
                  );
                } else if (snapshot.hasError) {
                  return NoInternetConnection(
                    action: () async {
                      await model.setHomeScreen();
                      await model.setLiveScreen();
                      await model.setPhotoScreen();
                    },
                  );
                }
            }
          },
        );
      },
    );
  }
}
