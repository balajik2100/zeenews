import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/utils/zeenews_styles.dart';

// ignore: must_be_immutable
class CustomChipWidget extends StatelessWidget {
  final HomeResponseData film;

  CustomChipWidget({@required this.film});

  List<String> litems = ["Singer", "Dancer", "Hollywood", "Zee"];

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: litems
            .map((item) => new Chip(
                backgroundColor: CustomColors.ChipBackgroundColor,
                padding:
                    const EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                  Radius.circular(15),
                )),
                label: Text(
                  item,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF3649AE)),
                )))
            .toList());
  }
}
