import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/utils/zeenews_styles.dart';

class BlogWidgetScreen extends StatelessWidget {
  final HomeResponseData film;

  BlogWidgetScreen({@required this.film});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    var title = Text(
      film?.title,
      style: TextStyle(
        color: CustomColors.APP_TITLE_TXT_COLOR,
        fontWeight: FontWeight.normal,
        fontSize: CustomFontStyle.APP_BLOG_TXT_SIZE,
      ),
    );

    var verticallist = Container(
        child: Card(
            elevation: 3.0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Center(
                  child: new Container(
                      width: 50.0,
                      height: 50.0,
                      decoration: new BoxDecoration(
                          shape: BoxShape.circle,
                          image: new DecorationImage(
                              fit: BoxFit.cover,
                              image: new NetworkImage(
                                  "https://www.woolha.com/media/2019/06/buneary.jpg")))),
                ),
                Center(child: title),
              ],
            )));

    var horizontallist = Center(
        child: Container(
      height: 120.0,
      child: new ListView.builder(
        itemCount: 10,
        itemBuilder: (context, index) {
          return new Card(
              child: new Container(width: 200.0, child: verticallist));
        },
        scrollDirection: Axis.horizontal,
      ),
    ));

    var carousel_title = Center(
      child: Container(
        child: Align(
          alignment: Alignment.centerLeft,
          child: Container(
            padding: EdgeInsets.all(3.0),
            child: Text(
              film.title,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 12.0),
              textAlign: TextAlign.center,
              maxLines: 4,
            ),
          ),
        ),
      ),
    );

    return new Stack(
      children: <Widget>[carousel_title, horizontallist],
    );
  }
}
