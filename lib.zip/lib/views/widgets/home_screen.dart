import 'package:flutter/material.dart';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/view_models/main_page_view_model.dart';
import 'package:zeenews/views/widgets/home_screen_item.dart';
import 'package:zeenews/views/widgets/no_internet_connection.dart';
import 'package:scoped_model/scoped_model.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return ScopedModelDescendant<MainPageViewModel>(
      builder: (context, child, model) {
        return FutureBuilder<List<HomeResponseData>>(
          future: model.home,
          // ignore: missing_return
          builder: (_, AsyncSnapshot<List<HomeResponseData>> snapshot) {
            switch (snapshot.connectionState) {
              case ConnectionState.none:
              case ConnectionState.active:
              case ConnectionState.waiting:
                return Center(child: const CircularProgressIndicator());
              case ConnectionState.done:
                if (snapshot.hasData) {
                  var films = snapshot.data;
                  return ListView.builder(
                    itemCount: films == null ? 0 : films.length,
                    itemBuilder: (_, int index) {
                      var film = films[index];
                      if (index == 0) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Container(
                                padding: EdgeInsets.all(5.0),
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 0.2,
                                      color: Colors
                                          .grey //                   <--- border width here
                                      ),
                                ),
                                child: Stack(
                                  children: <Widget>[
                                    Image.network(
                                        "https://devpwa.zeenews.com/static/assets/photo_thumb3.jpg",
                                        height: 160.0,
                                        width: size.width,
                                        fit: BoxFit.fill),
                                    Container(
                                      padding: EdgeInsets.only(top:130.0),
                                      child:Center(
                                          child:Text(film.title,textAlign:TextAlign.center, style: TextStyle(color: Colors.white,fontSize: 14.0,fontWeight: FontWeight.bold)
                                      )
                                      ),
                                    )

                                  ],
                                )),
                            HomeScreenItem(film: film)
                          ],
                        );
                      }
                      return HomeScreenItem(film: film);
                    },
                  );
                } else if (snapshot.hasError) {
                  return NoInternetConnection(
                    action: () async {
                      await model.setHomeScreen();
                      await model.setLiveScreen();
                      await model.setPhotoScreen();
                    },
                  );
                }
            }
          },
        );
      },
    );
  }
}
