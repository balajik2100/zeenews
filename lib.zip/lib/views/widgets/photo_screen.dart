import 'package:flutter/material.dart';
import 'package:zeenews/models/photoresponse.dart';
import 'package:zeenews/view_models/main_page_view_model.dart';
import 'package:zeenews/views/widgets/no_internet_connection.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:zeenews/views/widgets/photo_screen_item.dart';

class PhotoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<MainPageViewModel>(
      builder: (context, child, model) {
        return FutureBuilder<List<PhotoResponseData>>(
          future: model.photos,
          // ignore: missing_return
          builder: (_, AsyncSnapshot<List<PhotoResponseData>> snapshot) {
            switch (snapshot.connectionState) {
              case ConnectionState.none:
              case ConnectionState.active:
              case ConnectionState.waiting:
                return Center(child: const CircularProgressIndicator());
              case ConnectionState.done:
                if (snapshot.hasData) {
                  var planets = snapshot.data;
                  return ListView.builder(
                    itemCount: planets == null ? 0 : planets.length,
                    itemBuilder: (_, int index) {
                      var planet = planets[index];
                      return PhotoScreenItem(planet: planet);
                    },
                  );
                } else if (snapshot.hasError) {
                  return NoInternetConnection(
                    action: () async {
                      await model.setHomeScreen();
                      await model.setLiveScreen();
                      await model.setPhotoScreen();
                    },
                  );
                }
            }
          },
        );
      },
    );
  }
}