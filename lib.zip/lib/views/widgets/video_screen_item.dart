import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:zeenews/models/photoresponse.dart';
import 'package:zeenews/utils/zeenews_styles.dart';

class VideosScreenItem extends StatelessWidget {
  final PhotoResponseData planet;

  VideosScreenItem({@required this.planet});

  @override
  Widget build(BuildContext context) {
    var title = Text(
      planet?.name,
      style: TextStyle(
        color: CustomColors.APP_TITLE_TXT_COLOR,
        fontWeight: FontWeight.bold,
        fontSize: CustomFontStyle.APP_FONT_SIZE,
      ),
    );

    var subTitle = Row(
      children: <Widget>[
        Icon(
          FontAwesomeIcons.users,
          color: CustomColors.APP_TITLE_TXT_COLOR,
          size: CustomFontStyle.APP_SUBTITLE_FONT_SIZE,
        ),
        Container(
          margin: const EdgeInsets.only(left: 7.0),
          child: Text(
            planet?.population,
            style: TextStyle(
              color: CustomColors.APP_TITLE_TXT_COLOR,
            ),
          ),
        ),
      ],
    );

    var vlist = Container(
        //padding:EdgeInsets.only(left: 10.0, right: 10.0, top: 6.0, bottom: 4.0),
        //color: Colors.white,
        child: Card(
            elevation: 3.0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Image.network(
                    "https://devpwa.zeenews.com/static/assets/photo_thumb3.jpg",
                    height: 100.0,
                    width: 120.0,
                    fit: BoxFit.fill),
                ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 10.0),
                  title: title,
                  subtitle: subTitle,
                ),
              ],
            ))
    );

    return new Column(
      children: <Widget>[
        Container(
          child:
          Align(
            alignment: Alignment.centerLeft,
            child: Container(
              padding: EdgeInsets.all(5.0),
              child: Text(planet.name,style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black,fontSize: 16.0),textAlign: TextAlign.left,),
            ),
          ),

        ),
        Container(
          height: 200.0,
          child: new ListView.builder(
            itemCount: 10,
            itemBuilder: (context, index) {
              return new Card(child: new Container(width: 260.0, child: vlist));
            },
            scrollDirection: Axis.horizontal,
          ),
        ),
      ],
    );
  }
}
