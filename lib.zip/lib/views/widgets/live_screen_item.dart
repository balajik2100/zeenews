import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:zeenews/models/liveresponse.dart';
import 'package:zeenews/utils/zeenews_styles.dart';

class LiveScreenItem extends StatelessWidget {
  final LiveResponseData character;

  LiveScreenItem({@required this.character});

  @override
  Widget build(BuildContext context) {
    var title = Text(
      character?.name,
      style: TextStyle(
        color: CustomColors.APP_TITLE_TXT_COLOR,
        fontWeight: FontWeight.bold,
        fontSize: CustomFontStyle.APP_FONT_SIZE,
      ),
    );

    var subTitle = Row(
      children: <Widget>[
        Text(
          character?.birthYear,
          style: TextStyle(
            color: CustomColors.APP_TITLE_TXT_COLOR,
          ),
        ),
        Container(
          margin: const EdgeInsets.only(left: 6.0),
          child: Icon(
            _genderSymbol(),
            color: CustomColors.APP_TITLE_TXT_COLOR.withAlpha(200),
            size: CustomFontStyle.APP_SUBTITLE_FONT_SIZE,
          ),
        ),
      ],
    );


    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
            padding:
            EdgeInsets.only(left: 10.0, right: 10.0, top: 6.0, bottom: 4.0),
            color: Colors.white,
            child: Card(
              elevation: 3.0,
              child: Row(children: <Widget>[
                Expanded(
                    flex: 6,
                    child: ListTile(
                      title: title,
                      subtitle: subTitle,
                    )),
                Expanded(
                  flex: 4,
                  child: Image.network(
                      "https://devpwa.zeenews.com/static/assets/photo_thumb3.jpg",
                      height: 100.0,
                      width: 100.0,
                      fit: BoxFit.fill),
                ),
              ]),
            ))
      ],
    );


   /* return Column(
      children: <Widget>[
        ListTile(
          leading: Icon(
            _affiliationSymbol(),
            color: Theme.of(context).primaryColorLight,
            size: 40.0,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20.0),
          title: title,
          subtitle: subTitle,
        ),
        Divider(),
      ],
    );*/
  }

//  IconData _affiliationSymbol() {
//    switch (character.name) {
//      case 'Luke Skywalker':
//        return FontAwesomeIcons.jediOrder;
//      case 'C-3PO':
//        return FontAwesomeIcons.rebel;
//      case 'R2-D2':
//        return FontAwesomeIcons.rebel;
//      case 'Darth Vader':
//        return FontAwesomeIcons.empire;
//      case 'Leia Organa':
//        return FontAwesomeIcons.galacticRepublic;
//      case 'Owen Lars':
//        return Icons.face;
//      case 'Beru Whitesun lars':
//        return Icons.face;
//      case 'R5-D4':
//        return FontAwesomeIcons.rebel;
//      case 'Biggs Darklighter':
//        return FontAwesomeIcons.rebel;
//      case 'Obi-Wan Kenobi':
//        return FontAwesomeIcons.jediOrder;
//      default:
//        return null;
//    }
//  }

  IconData _genderSymbol() {
    switch (character.gender) {
      case 'male':
        return FontAwesomeIcons.mars;
      case 'female':
        return FontAwesomeIcons.venus;
      case 'n/a':
        return FontAwesomeIcons.robot;
      default:
        return null;
    }
  }
}