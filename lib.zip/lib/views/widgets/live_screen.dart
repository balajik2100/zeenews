import 'package:flutter/material.dart';
import 'package:zeenews/models/liveresponse.dart';
import 'package:zeenews/view_models/main_page_view_model.dart';
import 'package:zeenews/views/widgets/live_screen_item.dart';
import 'package:zeenews/views/widgets/no_internet_connection.dart';
import 'package:scoped_model/scoped_model.dart';

class LiveScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return ScopedModelDescendant<MainPageViewModel>(
      builder: (context, child, model) {
        return FutureBuilder<List<LiveResponseData>>(
          future: model.live,
          // ignore: missing_return
          builder: (_, AsyncSnapshot<List<LiveResponseData>> snapshot) {
            switch (snapshot.connectionState) {
              // ignore: missing_return
              case ConnectionState.none:
              case ConnectionState.active:
              case ConnectionState.waiting:
                return Center(child: CircularProgressIndicator());
              case ConnectionState.done:
                if (snapshot.hasData) {
                  var characters = snapshot.data;
                  return ListView.builder(
                    itemCount: characters == null ? 0 : characters.length,
                    itemBuilder: (_, int index) {
                      var character = characters[index];
                      if (index == 0) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Container(
                                padding: EdgeInsets.all(5.0),
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 0.2,
                                      color: Colors
                                          .grey //                   <--- border width here
                                  ),
                                ),
                                child: Stack(
                                  children: <Widget>[
                                    Image.network(
                                        "https://devpwa.zeenews.com/static/assets/photo_thumb3.jpg",
                                        height: 160.0,
                                        width: size.width,
                                        fit: BoxFit.fill),
                                    Container(
                                      padding: EdgeInsets.only(top:130.0),
                                      child:Center(
                                          child:Text(character.name,textAlign:TextAlign.center, style: TextStyle(color: Colors.white,fontSize: 14.0,fontWeight: FontWeight.bold)
                                          )
                                      ),
                                    )

                                  ],
                                )),
                            LiveScreenItem(character: character)
                          ],
                        );
                      }
                      return LiveScreenItem(character: character);
                    },
                  );
                } else if (snapshot.hasError) {
                  return NoInternetConnection(
                    action: () async {
                      await model.setHomeScreen();
                      await model.setLiveScreen();
                      await model.setPhotoScreen();
                    },
                  );
                }
            }
          },
        );
      },
    );
  }
}