import 'package:flutter/material.dart';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/utils/zeenews_styles.dart';

class HomeScreenItem extends StatelessWidget {
  final HomeResponseData film;

  HomeScreenItem({@required this.film});

  @override
  Widget build(BuildContext context) {
    var title = Text(
      film?.title,
      style: TextStyle(
        color: CustomColors.APP_TITLE_TXT_COLOR,
        fontWeight: FontWeight.bold,
        fontSize: CustomFontStyle.APP_FONT_SIZE,
      ),
    );

    var subTitle = Row(
      children: <Widget>[
        Icon(
          Icons.movie,
          color: CustomColors.APP_TITLE_TXT_COLOR,
          size: CustomFontStyle.APP_SUBTITLE_FONT_SIZE,
        ),
        Container(
          margin: const EdgeInsets.only(left: 4.0),
          child: Text(
            film?.director,
            style: TextStyle(
              color: CustomColors.APP_TITLE_TXT_COLOR,
            ),
          ),
        ),
      ],
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
            padding:
                EdgeInsets.only(left: 10.0, right: 10.0, top: 6.0, bottom: 4.0),
            color: Colors.white,
            child: Card(
              elevation: 3.0,
              child: Row(children: <Widget>[
                Expanded(
                    flex: 6,
                    child: ListTile(
                      title: title,
                      subtitle: subTitle,
                    )),
                Expanded(
                  flex: 4,
                  child: Image.network(
                      "https://devpwa.zeenews.com/static/assets/photo_thumb3.jpg",
                      height: 100.0,
                      width: 100.0,
                      fit: BoxFit.fill),
                ),
              ]),
            ))
      ],
    );

    /*
    return Column(
      children: <Widget>[
        Container(
            padding:
                EdgeInsets.only(left: 10.0, right: 10.0, top: 6.0, bottom: 4.0),
            color: Colors.white,
            child: Card(
                elevation: 3.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:[
                    ListTile(
                      contentPadding:
                      const EdgeInsets.symmetric(horizontal: 20.0),
                      title: title,
                      subtitle: subTitle,
                    ),
                    Image.network(
                        "https://devpwa.zeenews.com/static/assets/photo_thumb3.jpg",
                        height: 120.0,
                        width: 120.0,
                        fit: BoxFit.fill),

                  ],
                )
            )
        )
      ],
    );*/
  }
}
