import 'dart:async';
import 'package:flutter/material.dart';
import 'package:toast/toast.dart';
import 'package:zeenews/utils/zeenews_styles.dart';
import 'package:zeenews/view_models/main_page_view_model.dart';
import 'package:zeenews/views/pages/hamburger.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:zeenews/views/widgets/addtab_screen.dart';
import 'package:zeenews/views/widgets/common_screen.dart';
import 'package:zeenews/views/widgets/home_screen.dart';
import 'package:zeenews/views/widgets/live_screen.dart';
import 'package:zeenews/views/widgets/photo_screen.dart';
import 'package:zeenews/views/widgets/video_screen.dart';

class MainPage extends StatefulWidget {
  final MainPageViewModel viewModel;
  final List<String> list;

  MainPage({Key key, @required this.viewModel, @required this.list})
      : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage>
    with SingleTickerProviderStateMixin {
  TabController tabController;
  List<Widget> tabWidgets;
  List<Widget> tempWidget;
  List<Widget> tabControllerWidgets;
  int selectedWidgetlength = 0;

  Future loadData() async {
    await widget.viewModel.setHomeScreen();
    await widget.viewModel.setLiveScreen();
    await widget.viewModel.setPhotoScreen();

    Toast.show("Reload Data:" + widget.list.toString(), context,
        duration: Toast.LENGTH_SHORT, gravity: Toast.BOTTOM);
  }

  @override
  void initState() {
    super.initState();

    tabWidgets = <Widget>[
      Tab(
        icon: Icon(Icons.home),
        text: Strings.HOME,
      ),
      Tab(icon: Icon(Icons.live_tv), text: Strings.LIVE),
      Tab(icon: Icon(Icons.photo), text: Strings.PHOTOS),
      Tab(icon: Icon(Icons.video_library), text: Strings.VIDEOS)
    ];
    tabControllerWidgets = <Widget>[
      HomeScreen(),
      LiveScreen(),
      PhotoScreen(),
      VideosScreen(),
    ];
    if (widget.list != null && widget.list.length > 0) {
      for (int i = 0; i < widget.list.length; i++) {
        tabWidgets.add(Tab(
            icon: addIcon(i, widget.list[i].toString()), text: widget.list[i]));
        tabControllerWidgets.add(CommonScreen());
      }
    }
    tabController = TabController(vsync: this, length: tabWidgets.length);
    loadData();
  }

  @override
  Widget build(BuildContext context) {
    TabBar tabBar = TabBar(
      controller: tabController,
      indicatorColor: Colors.white,
      indicatorWeight: 3.0,
      isScrollable: true,
      tabs: tabWidgets,
    );
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          Strings.APP_BAR_TITLE,
          style: TextStyle(
            fontFamily: 'Distant Galaxy',
          ),
        ),
        bottom: tabBar,
      ),
      body: ScopedModel<MainPageViewModel>(
        model: widget.viewModel,
        child: TabBarView(
            controller: tabController, children: tabControllerWidgets),
      ),
      drawer: Hamburger(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(builder: (context) => AddTabItem()));
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.red,
      ),
    );
  }

  @override
  void dispose() {
    tabController?.dispose();
    super.dispose();
  }

  addIcon(int i, String tabName) {
    if (tabName == "WORLD") {
      return Icon(Icons.cloud_circle);
    }
    if (tabName == "INDIA") {
      return Icon(Icons.location_city);
    }
    if (tabName == "ENTERTAINMENT") {
      return Icon(Icons.perm_media);
    }
    if (tabName == "LIFE STYLE") {
      return Icon(Icons.style);
    }
    if (tabName == "TECHNOLOGY") {
      return Icon(Icons.mobile_screen_share);
    }
    if (tabName == "STATES") {
      return Icon(Icons.ev_station);
    }
    if (tabName == "BUSINESS") {
      return Icon(Icons.business);
    }
    if (tabName == "BHOJPURI") {
      return Icon(Icons.location_city);
    }
  }
}
