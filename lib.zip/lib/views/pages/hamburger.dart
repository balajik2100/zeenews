import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zeenews/views/pages/news_card_list.dart';

class Hamburger extends StatelessWidget {
  final List<String> getCities = [
    'AHMEDABAD',
    'BENGALURU',
    'CHENNAI',
    'HYDERABAD',
    'KOLKATA',
    'MUMBAI',
    'PUNE'
  ];
  final List<String> getWorld = [
    'ASIA',
    'AFRICA',
    'AMERICAS',
    'HYDERABAD',
    'AUSTRALIA',
    'EUROPE'
  ];
  final List<String> getStates = [
    'Andhra Pradesh',
    'Arunachal Pradesh',
    'Assam',
    'Bihar',
    'Chhattisgarh',
    'Goa',
    'Gujarat',
    'Haryana',
    'Himachal Pradesh',
    'Jammu and Kashmir',
    'Jharkhand',
    'Karnataka',
    'Kerala',
    'Madhya Pradesh',
    'Maharashtra',
    'Manipur',
    'Meghalaya',
    'Mizoram',
    'Nagaland',
    'Odisha',
    'Punjab',
    'Rajasthan',
    'Sikkim',
    'Tamil Nadu',
    'Telangana',
    'Tripura',
    'Uttarakhand',
    'Uttar Pradesh',
    'West Bengal',
    'Andaman and Nicobar Islands',
    'Chandigarh',
    'Dadra and Nagar Haveli',
    'Daman and Diu',
    'Delhi',
    'Lakshadweep',
    'Puducherry',
  ];

  final List<String> getEntertainment = [
    'BOLLYWOOD',
    'MOVIE REVIEWS',
    'TELEVISION',
    'HOLLYWOOD',
    'MUSIC',
    'REGIONAL'
  ];
  final List<String> getSports = [
    'CRICKET',
    'FOOT BALL',
    'TENNIS',
    'BADMINTON',
    'OTHER SPORTS'
  ];
  final List<String> getBusiness = [
    'ECONOMY',
    'PERSONAL FINANCE',
    'COMPANIES',
    'INTERNATION BUSINESS',
    'REAL ESTATE',
    'BULLION',
    'AUTOMOBILE'
  ];
  final List<String> getTechnology = [
    'GADGET',
    'GAMING',
    'INTERNET & SOCIAL MEDIA',
    'APPS',
    'MOBILE'
  ];
  final List<String> getLifeStyle = [
    'TRAVEL',
    'FOOD & RECIPES',
    'PEOPLE',
    'RELATIONSHIP',
    'SPIRITUALITY',
    'FASHION',
    'CULTURE'
  ];
  final List<String> getScienceandEnvironment = [
    'SPACE',
    'ENVIRONMENT',
    'SCIENCE',
    'DISCOVERY'
  ];
  final List<String> getSettingMenu = [
    'CONTACT US',
    'COMPAINT',
    'INVESTOR INFO',
    'CAREERS',
    'PRIVACY POLICY',
    'LEGAL DISCAIMER',
    'ADVERTISE WITH US',
    'WHERE TO WATCH'
  ];
  final List<String> getPartnerIconsLogo = [
    'assets/images/zeenews_hindi.png',
    'assets/images/zeenews_kanada.png',
    'assets/images/zeenews_telugu.png'
  ];
  final List<String> getConnectWithUs = [

    'assets/images/zeenews_kanada.png',
    'assets/images/zeenews_telugu.png'
  ];

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: UserAccountsDrawerHeader(
              accountName: Text("User_Name"),
              accountEmail: Text("User_Email@zee.esselgroup.com"),
              currentAccountPicture: CircleAvatar(
                backgroundColor:
                    Theme.of(context).platform == TargetPlatform.iOS
                        ? Colors.blue
                        : Colors.white,
                child: Text(
                  "A",
                  style: TextStyle(fontSize: 40.0),
                ),
              ),
            ),
          ),
          ListTile(
            title: Text('HOME'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => NewsCardsListView("HOME", true, "")));

            },
          ),
          ListTile(
            title: Text('BRIEF'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => NewsCardsListView("BRIEF", true, "")));
            },
          ),
          ListTile(
            title: Text('LATEST'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => NewsCardsListView("LATEST", true, "")));
            },
          ),
          ListTile(
            title: Text('VIDEOS'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => NewsCardsListView("VIDEOS", true, "")));
            },
          ),
          ExpansionTile(
            title: Text("INDIA"),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getCities)],
          ),
          ListTile(
            title: Text('PHOTOS'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => NewsCardsListView("PHOTOS", true, "")));
            },
          ),
          ExpansionTile(
            title: Text('WORLD'),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getWorld)],
          ),
          ExpansionTile(
            title: Text('STATES'),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getStates)],
          ),
          ExpansionTile(
            title: Text('ENTERTAINMENT'),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getEntertainment)],
          ),
          ExpansionTile(
            title: Text('SPORTS'),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getSports)],
          ),
          ExpansionTile(
            title: Text('BUSINESS'),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getBusiness)],
          ),
          ListTile(
            title: Text('HEALTH'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => NewsCardsListView("HEALTH", true, "")));
            },
          ),
          ExpansionTile(
            title: Text('TECHNOLOGY'),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getTechnology)],
          ),
          ExpansionTile(
            title: Text('LIFESTYLE'),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getLifeStyle)],
          ),
          ExpansionTile(
            title: Text('SCIENCE & ENVIRONMENT'),
            trailing: Icon(Icons.add),
            leading: Icon(Icons.home),
            children: [
              getItemsListForSideMenu(context, getScienceandEnvironment)
            ],
          ),
          ListTile(
            title: Text('BLOGS'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => NewsCardsListView("BLOGS", true, "")));
            },
          ),
          ExpansionTile(
            title: Text('SETTINGS'),
            leading: Icon(Icons.settings),
            trailing: Icon(Icons.add),
            children: [getItemsListForSideMenu(context, getSettingMenu)],
          ),
          ExpansionTile(
            title: Text('PARTNER SITES'),
            leading: Icon(Icons.web),
            trailing: Icon(Icons.add),
            children: [
              // getItemsListForSideMenu_Partner(context, getPartnerIconsLogo)
              getItemsListForSideMenu_PartnerLogo(context, getPartnerIconsLogo)
            ],
          ),

        ],
      ),
    );
  }

  // map() + toList()
  Widget getItemsListForSideMenu(BuildContext context, List<String> itemList) {

    return Column(
      // Text('You CANNOT put other Widgets here'),
      children: itemList
          .map((item) => ListTile(
                title: Text(item),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => NewsCardsListView(item, true, "")));
                },
                contentPadding: EdgeInsets.only(left: 55.0),
              ))
          .toList(),
    );
  }

  Widget getItemsListForSideMenu_PartnerLogo(BuildContext context, List<String> itemList) {
    return new Container(
      child: new GridView.count(
        crossAxisCount: 3,
        controller: new ScrollController(keepScrollOffset: false),
        shrinkWrap: true,
        scrollDirection: Axis.vertical,
        children: itemList.map((String value) {
          return new Container(
            margin: new EdgeInsets.all(2),
            padding: new EdgeInsets.all(2),
            child:Image(
              image: AssetImage(value),
              width: 5.0,
              height: 5.0,
              fit: BoxFit.contain,
            ),
          );
        }).toList(),
      ),
    );
  }
}

class SliderDrawerTitleList {
  final Text itemName;

  SliderDrawerTitleList({
    @required this.itemName,
  }) {
    assert(itemName != null);
  }
}
