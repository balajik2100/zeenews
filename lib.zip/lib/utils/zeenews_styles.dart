import 'dart:ui';

class Strings {
  static const String APP_BAR_TITLE = "ZEE NEWS";
  static const String HOME = "HOME";
  static const String LIVE = "LIVE TV";
  static const String PHOTOS = "PHOTOS";
  static const String VIDEOS = "VIDEOS";
}
class CustomColors {

  static const APP_BAR_COLOR = Color(0xFFF44336);
  static const APP_TITLE_TXT_COLOR = Color(0xFF000000);

  static const PrimaryColor =  Color(0xFF3366FF);
  static const PrimaryAssentColor =  Color(0xFF3366FF);
  static const PrimaryDarkColor =  Color(0xFF3366FF);
  static const ErroColor =  Color(0xFF3366FF);
  static const ChipBackgroundColor =  Color(0xFFE1E4F3);
}
class Configuration {
  static const String BASE_URL = "https://swapi.co/api";
}
class CustomFontStyle {
  static const double APP_FONT_SIZE = 18.0;
  static const double APP_SUBTITLE_FONT_SIZE = 16.0;
  static const double APP_BLOG_TXT_SIZE = 12.0;
}