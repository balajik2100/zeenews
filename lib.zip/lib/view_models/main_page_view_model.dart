import 'dart:async';
import 'package:meta/meta.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:zeenews/interfaces/zee_api_interface.dart';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/models/liveresponse.dart';
import 'package:zeenews/models/photoresponse.dart';

class MainPageViewModel extends Model {
  Future<List<HomeResponseData>> _home;
  Future<List<HomeResponseData>> get home => _home;
  set home(Future<List<HomeResponseData>> value) {
    _home = value;
    notifyListeners();
  }

  Future<List<LiveResponseData>> _live;
  Future<List<LiveResponseData>> get live => _live;
  set live(Future<List<LiveResponseData>> value) {
    _live = value;
    notifyListeners();
  }

  Future<List<PhotoResponseData>> _photos;
  Future<List<PhotoResponseData>> get photos => _photos;
  set photos(Future<List<PhotoResponseData>> value) {
    _photos = value;
    notifyListeners();
  }

  final ZeeNewsAPIInterface apiZeeNews;

  MainPageViewModel({@required this.apiZeeNews});

  Future<bool> setHomeScreen() async {
    home = apiZeeNews?.getHomeScreen();
    return home != null;
  }

  Future<bool> setLiveScreen() async {
    live = apiZeeNews?.getLiveScreen();
    return live != null;
  }

  Future<bool> setPhotoScreen() async {
    photos = apiZeeNews?.getPhotoScreen();
    return photos != null;
  }
}