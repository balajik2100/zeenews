import 'package:flutter/material.dart';
import 'package:zeenews/services/zee_api_service.dart';
import 'package:zeenews/utils/zeenews_styles.dart';
import 'package:zeenews/view_models/main_page_view_model.dart';
import 'package:zeenews/views/pages/main_page.dart';

final MainPageViewModel mainPageVM = MainPageViewModel(apiZeeNews: ZeeAPIService());

void main() => runApp(ZeeHome(mainPageVM: mainPageVM));

// ignore: must_be_immutable
class ZeeHome extends StatelessWidget {
  final MainPageViewModel mainPageVM;
  List<String> tempList = [];
  ZeeHome({@required this.mainPageVM});

  @override
  Widget build(BuildContext context) {
    return
      new MaterialApp(
      title: Strings.APP_BAR_TITLE,
      theme: new ThemeData(
        primaryColor: CustomColors.APP_BAR_COLOR,
        primaryColorLight:CustomColors.APP_BAR_COLOR,
        primaryColorDark: CustomColors.APP_BAR_COLOR,
      ),
      home: MainPage(viewModel: mainPageVM,list: tempList,),
      debugShowCheckedModeBanner: false,
    );
  }
}