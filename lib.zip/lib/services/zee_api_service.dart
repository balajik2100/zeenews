import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:zeenews/interfaces/zee_api_interface.dart';
import 'package:zeenews/models/homeresponse.dart';
import 'package:zeenews/models/liveresponse.dart';
import 'package:zeenews/models/photoresponse.dart';
import 'package:zeenews/utils/zeenews_styles.dart';

class ZeeAPIService implements ZeeNewsAPIInterface {
  final _baseUrl = Configuration.BASE_URL;
  http.Client _client = http.Client();

  set client(http.Client value) => _client = value;

  static final ZeeAPIService _internal = ZeeAPIService.internal();
  factory ZeeAPIService() => _internal;
  ZeeAPIService.internal();

  Future<List<HomeResponseData>> getHomeScreen() async {
    var response = await _client.get('$_baseUrl/films');

    if (response.statusCode == 200) {
      var data = json.decode(response.body);

      List<dynamic> filmsData = data['results'];
      List<HomeResponseData> films = filmsData.map((f) => HomeResponseData.fromMap(f)).toList();

      return films;
    } else {
      throw Exception('Failed to get data');
    }
  }

  Future<List<LiveResponseData>> getLiveScreen() async {
    var response = await _client.get('$_baseUrl/people');

    if (response.statusCode == 200) {
      var data = json.decode(response.body);

      List<dynamic> charactersData = data['results'];
      List<LiveResponseData> characters =
          charactersData.map((c) => LiveResponseData.fromMap(c)).toList();

      return characters;
    } else {
      throw Exception('Failed to get data');
    }
  }

  Future<List<PhotoResponseData>> getPhotoScreen() async {
    var response = await _client.get('$_baseUrl/planets');

    if (response.statusCode == 200) {
      var data = json.decode(response.body);

      List<dynamic> planetsData = data['results'];
      List<PhotoResponseData> planets = planetsData.map((p) => PhotoResponseData.fromMap(p)).toList();

      return planets;
    } else {
      throw Exception('Failed to get data');
    }
  }

  @override
  Future<List<PhotoResponseData>> getVideoScreen() async{
    // TODO: implement getVideoScreen
    var response = await _client.get('$_baseUrl/planets');

    if(response.statusCode ==200){
      var data = json.decode(response.body);

      List<dynamic> videoData = data['results'];
      List<PhotoResponseData> planets = videoData.map((p) => PhotoResponseData.fromMap(p)).toList();

      return planets;
    }else {
      throw Exception('Failed to get data');
    }

  }
}